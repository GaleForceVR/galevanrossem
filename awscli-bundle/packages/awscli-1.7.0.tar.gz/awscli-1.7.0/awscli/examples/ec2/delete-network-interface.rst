**To delete a network interface**

This example deletes the specified network interface. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-network-interface --network-interface-id eni-e5aa89a3
